# MANIGUADEBABY.COM — Site complet V1

Projet Next.js prêt à être téléchargé et déployé.

## Installation
npm install
npm run dev

## Production
npm run build
npm start

## Domaine
Ajouter `maniguadebaby.com` dans Vercel puis utiliser exactement les DNS indiqués par Vercel.

## Inclus
Accueil, artistes, nouveautés, albums, singles, vidéos, actualités, événements, téléchargement, streaming, boutique, services, publicité, blog, contact, espace artiste et administration.

La V1 contient des contenus de démonstration et un court audio de test. Les paiements, comptes réels, stockage cloud et fichiers musicaux réels doivent être connectés avant la mise en production.
